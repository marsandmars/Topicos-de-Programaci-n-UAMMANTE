package com.example.miagendita

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.*
import android.widget.BaseAdapter
import android.widget.SearchView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.molde_notas.view.*

class MainActivity(var adapter:NotasAdapter?=null) : AppCompatActivity() {
    //creo una variable llamada listaDeNotas tipo ArrayList de la clase Notas.kt
    var listaDeNotas=ArrayList<Notas>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //Agrego una tres notas a la lista listaDeNotas de manera manual, solo en memoria
        //listaDeNotas.add(Notas(1,"Titulo","Descricion"))
        //listaDeNotas.add(Notas(2,"Titulo","Descricion"))
        //listaDeNotas.add(Notas(2,"Titulo","Descricion"))
        //adapter = NotasAdapter(this, listaDeNotas)
        //listView.adapter=adapter
        cargarQuery("%") //Carga cualquier titulo que le llegue
    }

    //SELECT ID, Titulo, Descripcion FROM Notas Where 8Titulo like ?)
    fun cargarQuery(titulo:String) {
        var baseDatos=DBManager(this)
        val columnas=arrayOf("ID","Titulo","Descripcion")
        val selectionArgs= arrayOf(titulo)
        val cursor=baseDatos.query(columnas,"Titulo like ?", selectionArgs,"Titulo")

        if (cursor.moveToFirst()){
            do{
                val ID=cursor.getInt(cursor.getColumnIndex("ID"))
                val titulo=cursor.getString(cursor.getColumnIndex("Titulo"))
                val descripcion = cursor.getString(cursor.getColumnIndex("Descripcion"))

            }while (cursor.moveToFirst())
        }
    }

    //Sobreescribir la siguiente opción
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        //Renderizar menu pasarle las opciones de menu
        menuInflater.inflate(R.menu.menu, menu)
        val buscar = menu!!.findItem(R.id.app_bar_search).actionView as SearchView //implementar a lógica de buscar
        val manejador =getSystemService(Context.SEARCH_SERVICE) as SearchManager   //
        buscar.setSearchableInfo(manejador.getSearchableInfo(componentName))

        //escuachador o listener del evento de buscar
        buscar.setOnQueryTextListener(object:SearchView.OnQueryTextListener{
            override fun onQueryTextSubmit(p0:String?):Boolean{
                Toast.makeText(applicationContext,p0, Toast.LENGTH_SHORT).show()
                cargarQuery("%"+p0+"%") //va a buscar lo que coincida con el titulo
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
               return false
            }
        })

        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item!!.itemId){
            R.id.menuAgregar-> {
                var intent = Intent(this, AddActivity::class.java)
                startActivity(intent)
            }
        }
        return super.onOptionsItemSelected(item)
    }

    //Adaptador de Notas para pantalla
    class NotasAdapter(contexto: Context, var listaDeNotas:ArrayList<Notas>): BaseAdapter() {

        var contexto:Context?=contexto

        override fun getView(p0:Int, p1:View?, pw:ViewGroup?): View {
            var nota=listaDeNotas[p0]
            val inflater = contexto!!.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
            val miVista=inflater.inflate(R.layout.molde_notas,null)
            miVista.textViewTitulo.text=nota.titulo
            miVista.textViewContenido.text=nota.descripcion
            return miVista
        }

        override fun getItem(p0:Int): Any {
            return listaDeNotas[p0]
        }

        override fun getItemId(p0:Int): Long {
            return p0.toLong()
        }

        override fun getCount(): Int {
            return listaDeNotas.size
        }
    }
}

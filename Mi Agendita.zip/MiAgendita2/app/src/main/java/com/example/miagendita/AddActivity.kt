package com.example.miagendita

import android.content.ContentValues
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_add.*

class AddActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add)
    }

    fun btnAdd(view:View){
        val baseDatos=DBManager(this)
        val values = ContentValues()
        // en este metodo values.put  se le pasa "Titulo" como referenciador y el valor que se esta poniendo en pantalla
        values.put("Titulo",editTextTitulo.text.toString())
        values.put("Descripcion",editTextContenido.text.toString())

        val ID =baseDatos.insert(values)
        if (ID>0){
            Toast.makeText(this, "Nota agregada correctamente", Toast.LENGTH_LONG).show()
            finish()
        }else {
            Toast.makeText(this,"Nota No agreagda",Toast.LENGTH_LONG).show()
        }
    }
}

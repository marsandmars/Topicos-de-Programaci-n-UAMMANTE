package com.example.miagendita

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.database.sqlite.SQLiteQueryBuilder
import android.widget.Toast

class DBManager{
    //Atributos de la Base de datos
    val dbNombre="MisNotas"
    val dbTabla="Notas"
    val columnaID="ID"
    val columnaTitulo="Titulo"
    val columnaDescripcion="Descripcion"
    val dbVersion=1
    val sqlCrearTabla="CREATE TABLE IF NOT EXISTS "+dbTabla+" ("+columnaID+" INTEGER PRIMARY KEY AUTOINCREMENT,"+columnaTitulo+" TEXT NOT NULL,"+
            columnaDescripcion+" TEXT NOT NULL)"
    //creo una variable llamada sqlDB y se extiende a SQLiteDatabase y se le da el valor de nulo
    var sqlDB: SQLiteDatabase?=null

    //Constructor de la clase de DBManager se le pasa el contexto de la aplicación
    //Creo una variable llamada db que es igual a la clase DBHelperNotas
    //posterior se crea otra variable llamada sqlDB que invoca un metodo por medio de db.writableDatabase para
    constructor(contexto:Context) {
        val db = DBHelperNotas(contexto)
        //con el siguiente metodo le decimos que la base de datos se pueda escribir
        sqlDB=db.writableDatabase
    }


    //La siguiente clase accesa a los valores de las variables creadas con anterioridad al declararse inner
    //Los Metodos OnCreate y OnUpgrade se sobreescriben
    inner class DBHelperNotas(contexto:Context):SQLiteOpenHelper(contexto, dbNombre, null,dbVersion){
        var contexto:Context?=contexto //variable de conexto se extiende a Context y se le da el valor contexto que se le pasa como valor a la clase DBHelperNotas

        //En el metodo onCreate se le pasa el valor almacenado en sqlDB que de inicio es null y que esta hereda o se extiende de la clase SQLiteDatabase
        //-----------------------------------------------------------------------------------------------------------------------------------------------------------
        //p0 es de tipo SQLiteDatabase y que sirve para invocar diversos metodos que tienen efecto sobre la base de datos
        //p0 accesa a un método execSQL(sqlCrearTabla) y le pasa el valor del query almacenado en sqlCrearTabla
        // aquí p0 crea la tabla en la base de datos
        // el Toast nos avisa en pantalla cuando la BD es creada
        override fun onCreate(p0: SQLiteDatabase?) {
              p0!!.execSQL(sqlCrearTabla)
              Toast.makeText(this.contexto, "Base de Datos Creada",Toast.LENGTH_SHORT).show()
        }
        override fun onUpgrade(p0: SQLiteDatabase?, p1: Int, p2: Int) {
            p0!!.execSQL("Drop Table IF EXIST"+dbTabla)
        }

    }

    //Insertar datos en la base de datos
    fun insert (values: ContentValues):Long {
        val ID=sqlDB!!.insert(dbTabla, "", values)
        return ID

    }


    //******************************************************************************************************************************
    //********************** consulta a la base de datos **************************************************************************
    //query nos retorna un objeto tipo cursor
    //projection: son las Columnas
    //Selection : son el cuerpo de la sentencia WHERE con las columnas que condicionamos
    //SelectionArgs: es una lista de los valores que se usaran para reemplazar el selection
    //OrderBy: como queremos que se ordene
    fun  query(projection:Array<String>, selection:String, selectionArgs:Array<String>,orderBy:String):Cursor {
        // projection son las columnas de nuestra tabla
        //selection = cuerpo de la sentencia, aqui va ir el contenido de select * from where y sentencias similares
        //selectionArgs= valores que se usaran para ir remplazando los valores

        val consulta=SQLiteQueryBuilder()
        consulta.tables=dbTabla
        val cursor=consulta.query(sqlDB, projection, selection, selectionArgs,null,null,orderBy)
        return cursor
    }


    //**************************************************************************************************************************

    //la implementacion de toda esta clase DBManager se termina en la pestaña de AddActivity.kt que es donde se inserta los datos en la base
}